package com.loopvault.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Future
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var store: VaultStore
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val autoLock = Runnable { lockVault("Locked after being in the background") }
    private var masterKey: ByteArray? = null
    private var videos = mutableListOf<VaultStore.VideoItem>()
    private var selected = -1
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var root: SwipeFrameLayout? = null
    private var statusText: TextView? = null
    private var busy = false
    private var loadToken = 0
    private var cropMode = false
    private var importInProgress = false
    private var playbackFuture: Future<*>? = null
    private var currentPlaybackFile: File? = null
    private var appInBackground = false
    private var pickerOpen = false

    companion object {
        private const val REQUEST_IMPORT = 4312
        private const val BACKGROUND_LOCK_MS = 60_000L
        private const val BG = 0xFF08090B.toInt()
        private const val PANEL = 0xFF15171C.toInt()
        private const val LIME = 0xFFC7FF3D.toInt()
        private const val WHITE = 0xFFF4F5F6.toInt()
        private const val MUTED = 0xFF9DA2AA.toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        store = VaultStore(contentResolver, File(noBackupFilesDir, "loop-vault"), File(cacheDir, "loop-playback"))
        store.clearPlaybackCopies()
        if (store.isReady()) showUnlockScreen()
        else if (store.isPristine()) showCreatePasswordScreen()
        else showBrokenVaultScreen()
    }

    override fun onResume() {
        super.onResume()
        appInBackground = false
        handler.removeCallbacks(autoLock)
    }

    override fun onPause() {
        super.onPause()
        appInBackground = true
        if (masterKey != null && !importInProgress && !pickerOpen) handler.postDelayed(autoLock, BACKGROUND_LOCK_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoLock)
        releasePlayer()
        masterKey?.fill(0)
        masterKey = null
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun showCreatePasswordScreen() {
        val page = authPage(
            title = "Create your private vault",
            subtitle = "Set a password. Videos you add will be encrypted inside LOOP and kept out of your Gallery."
        )
        val password = passwordField("Create password")
        val confirm = passwordField("Confirm password")
        page.addView(password, fieldParams())
        page.addView(confirm, fieldParams())
        page.addView(note("Use at least 8 characters. There is no password reset: if you forget it, the encrypted videos cannot be recovered."), fieldParams(top = 8))
        page.addView(actionButton("CREATE VAULT") {
            if (busy) return@actionButton
            val first = password.text?.toString().orEmpty()
            val second = confirm.text?.toString().orEmpty()
            if (first.length < 8) { toast("Use at least 8 characters"); return@actionButton }
            if (first != second) { toast("The passwords do not match"); return@actionButton }
            val chars = first.toCharArray()
            password.text?.clear()
            confirm.text?.clear()
            busy = true
            val progress = note("Creating encrypted vault…")
            page.addView(progress, fieldParams(top = 12))
            worker.execute {
                try {
                    val key = store.createVault(chars)
                    runOnUiThread {
                        busy = false
                        masterKey = key
                        videos = mutableListOf()
                        selected = -1
                        showReelsScreen("Vault created. Add your first videos.")
                    }
                } catch (e: Exception) {
                    runOnUiThread { busy = false; toast("Could not create the vault: ${e.message ?: "unknown error"}") }
                }
            }
        }, fieldParams(top = 18))
        setContent(page)
    }

    private fun showUnlockScreen() {
        val page = authPage("Unlock LOOP", "Your private videos are encrypted. Enter your password to open the vault.")
        val password = passwordField("Vault password")
        page.addView(password, fieldParams())
        page.addView(actionButton("UNLOCK") {
            if (busy) return@actionButton
            busy = true
            val chars = password.text?.toString().orEmpty().toCharArray()
            password.text?.clear()
            val progress = note("Unlocking…")
            page.addView(progress, fieldParams(top = 10))
            worker.execute {
                try {
                    val key = store.unlock(chars)
                    val items = store.readItems(key)
                    runOnUiThread {
                        busy = false
                        masterKey = key
                        videos = items
                        selected = if (videos.isNotEmpty()) 0 else -1
                        showReelsScreen(if (videos.isEmpty()) "Your vault is empty. Add videos to get started." else "Vault unlocked")
                    }
                } catch (_: javax.crypto.AEADBadTagException) {
                    runOnUiThread { busy = false; toast("Incorrect password") }
                } catch (e: Exception) {
                    runOnUiThread { busy = false; toast("Could not unlock vault: ${e.message ?: "vault error"}") }
                }
            }
        }, fieldParams(top = 16))
        page.addView(note("This app never uploads your videos. Keep a safe copy of originals elsewhere."), fieldParams(top = 18))
        setContent(page)
    }

    private fun showBrokenVaultScreen() {
        val page = authPage("Vault needs attention", "LOOP found an incomplete vault folder. It will not overwrite it automatically.")
        page.addView(note("Do not clear app storage if you need the encrypted videos. If this happened after a failed first setup, the safest next step is to contact the project maintainer or reinstall only after confirming there are no saved videos."), fieldParams())
        page.addView(actionButton("CLOSE APP") { finish() }, fieldParams(top = 18))
        setContent(page)
    }

    private fun authPage(title: String, subtitle: String): LinearLayout {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(26), dp(30), dp(26), dp(30))
            setBackgroundColor(BG)
        }
        val logo = text("LOOP", 38, LIME, true).apply { letterSpacing = 0.16f; gravity = Gravity.CENTER }
        content.addView(logo, LinearLayout.LayoutParams(-1, -2))
        content.addView(text("PRIVATE VIDEO VAULT", 11, MUTED, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.18f }, fieldParams(top = 5, bottom = 30))
        content.addView(text(title, 24, WHITE, true), fieldParams(bottom = 10))
        content.addView(text(subtitle, 14, MUTED, false), fieldParams(bottom = 24))
        return content
    }

    private fun showReelsScreen(message: String? = null) {
        releasePlayer()
        val frame = SwipeFrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            onSwipe = { direction -> if (videos.isNotEmpty()) selectVideo((selected + direction).coerceIn(0, videos.lastIndex)) }
        }
        root = frame
        val player = ExoPlayer.Builder(this).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
            playWhenReady = true
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_ENDED && videos.isNotEmpty() && selected < videos.lastIndex) selectVideo(selected + 1)
                }
            })
        }
        this.player = player
        val videoSurface = PlayerView(this).apply {
            useController = true
            resizeMode = if (cropMode) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            this.player = player
            setShutterBackgroundColor(Color.BLACK)
        }
        playerView = videoSurface
        frame.addView(videoSurface, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(12), dp(10))
            setBackgroundColor(0x9908090B.toInt())
        }
        val brand = text("LOOP", 20, LIME, true)
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val count = text("0 VIDEOS", 11, MUTED, true)
        statusText = count
        top.addView(count, LinearLayout.LayoutParams(-2, -2))
        top.addView(actionButton("LOCK") { lockVault("Vault locked") }.apply { textSize = 11f }, LinearLayout.LayoutParams(-2, dp(42)))
        frame.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(18))
            setBackgroundColor(0xB308090B.toInt())
        }
        val filename = text("No video selected", 13, WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        filename.tag = "filename"
        bottom.addView(filename, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 5f }
        controls.addView(actionButton("PREV") { if (selected > 0) selectVideo(selected - 1) }, weightParams())
        controls.addView(actionButton("ADD") { launchImportPicker() }, weightParams())
        controls.addView(actionButton("NEXT") { if (selected < videos.lastIndex) selectVideo(selected + 1) }, weightParams())
        controls.addView(actionButton("FIT") { toggleFit() }, weightParams())
        controls.addView(actionButton("LIBRARY") { showLibrary() }, weightParams())
        bottom.addView(controls)
        bottom.addView(actionButton("DELETE CURRENT VIDEO") { confirmDeleteCurrent() }.apply { textSize = 11f }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(7) })
        frame.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContent(frame)
        updateReelLabels()
        if (videos.isNotEmpty() && selected in videos.indices) loadSelectedVideo()
        else if (message != null) toast(message)
    }

    private fun updateReelLabels() {
        statusText?.text = "${videos.size} VIDEO${if (videos.size == 1) "" else "S"}"
        val frame = root ?: return
        val bottom = frame.getChildAt(frame.childCount - 1) as? LinearLayout ?: return
        val filename = bottom.getChildAt(0) as? TextView ?: return
        filename.text = if (selected in videos.indices) videos[selected].name else "Your private reels are ready"
    }

    private fun selectVideo(index: Int) {
        if (index !in videos.indices) return
        selected = index
        updateReelLabels()
        loadSelectedVideo()
    }

    private fun loadSelectedVideo() {
        val key = masterKey?.copyOf() ?: return
        val index = selected
        val item = videos.getOrNull(index) ?: run { key.fill(0); return }
        playbackFuture?.cancel(true)
        val token = ++loadToken
        val currentPlayer = player ?: run { key.fill(0); return }
        currentPlayer.stop()
        currentPlayer.clearMediaItems()
        currentPlaybackFile?.delete()
        currentPlaybackFile = null
        playbackFuture = worker.submit {
            try {
                val clearFile = store.decryptForPlayback(item, key)
                runOnUiThread {
                    if (token != loadToken || masterKey == null || selected != index) {
                        clearFile.delete()
                    } else {
                        currentPlaybackFile = clearFile
                        currentPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(clearFile)))
                        currentPlayer.prepare()
                        currentPlayer.playWhenReady = true
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { if (token == loadToken) toast("Could not play this video: ${e.message ?: "file error"}") }
            } finally {
                key.fill(0)
            }
        }
    }

    private fun launchImportPicker() {
        if (masterKey == null || importInProgress) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            pickerOpen = true
            startActivityForResult(intent, REQUEST_IMPORT)
        } catch (_: Exception) {
            pickerOpen = false
            toast("Could not open the Android file picker")
        }
    }

    @Deprecated("Uses the Android document picker to import selected videos")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_IMPORT) return
        pickerOpen = false
        if (resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let(uris::add)
        if (uris.isEmpty()) return
        importVideos(uris.distinct())
    }

    private fun importVideos(uris: List<Uri>) {
        val key = masterKey?.copyOf() ?: return
        importInProgress = true
        toast("Importing ${uris.size} video${if (uris.size == 1) "" else "s"}…")
        worker.execute {
            val added = mutableListOf<VaultStore.VideoItem>()
            try {
                uris.forEach { uri -> added.add(store.importVideo(uri, key)) }
                val newList = videos.toMutableList().apply { addAll(added) }
                store.saveItems(newList, key)
                runOnUiThread {
                    importInProgress = false
                    if (appInBackground && masterKey != null) handler.postDelayed(autoLock, BACKGROUND_LOCK_MS)
                    videos = newList
                    selected = videos.lastIndex
                    updateReelLabels()
                    loadSelectedVideo()
                    toast("Added ${added.size} video${if (added.size == 1) "" else "s"}")
                }
            } catch (e: Exception) {
                added.forEach(store::deleteVideo)
                runOnUiThread {
                    importInProgress = false
                    if (appInBackground && masterKey != null) handler.postDelayed(autoLock, BACKGROUND_LOCK_MS)
                    toast("Import failed: ${e.message ?: "could not read video"}")
                }
            } finally { key.fill(0) }
        }
    }

    private fun showLibrary() {
        if (videos.isEmpty()) { toast("Your vault is empty"); return }
        val names = videos.mapIndexed { i, v -> "${if (i == selected) "▶  " else "     "}${v.name}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Your videos (${videos.size})")
            .setItems(names) { _, which -> selectVideo(which) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirmDeleteCurrent() {
        val item = videos.getOrNull(selected) ?: run { toast("No video selected"); return }
        AlertDialog.Builder(this)
            .setTitle("Delete this video?")
            .setMessage("${item.name}\n\nThe encrypted copy will be deleted from LOOP. Your original file will not be touched.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ -> deleteCurrent(item) }
            .show()
    }

    private fun deleteCurrent(item: VaultStore.VideoItem) {
        if (importInProgress) { toast("Wait for the current import to finish"); return }
        val key = masterKey?.copyOf() ?: return
        player?.stop()
        player?.clearMediaItems()
        currentPlaybackFile?.delete()
        currentPlaybackFile = null
        ++loadToken
        worker.execute {
            try {
                store.deleteVideo(item)
                val updated = videos.toMutableList().apply { removeAll { it.id == item.id } }
                store.saveItems(updated, key)
                runOnUiThread {
                    videos = updated
                    selected = when { videos.isEmpty() -> -1; selected >= videos.size -> videos.lastIndex; else -> selected }
                    updateReelLabels()
                    if (selected >= 0) loadSelectedVideo() else toast("Video deleted. Your vault is now empty.")
                }
            } catch (e: Exception) { runOnUiThread { toast("Delete failed: ${e.message ?: "unknown error"}") } }
            finally { key.fill(0) }
        }
    }

    private fun toggleFit() {
        cropMode = !cropMode
        playerView?.resizeMode = if (cropMode) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
        toast(if (cropMode) "Fill screen (may crop edges)" else "Fit whole video")
    }

    private fun lockVault(message: String) {
        if (masterKey == null) return
        if (importInProgress) { toast("Please wait for the video import to finish before locking"); return }
        handler.removeCallbacks(autoLock)
        ++loadToken
        playbackFuture?.cancel(true)
        playbackFuture = null
        releasePlayer()
        masterKey?.fill(0)
        masterKey = null
        videos.clear()
        selected = -1
        store.clearPlaybackCopies()
        showUnlockScreen()
        toast(message)
    }

    private fun releasePlayer() {
        playbackFuture?.cancel(true)
        playbackFuture = null
        currentPlaybackFile?.delete()
        currentPlaybackFile = null
        playerView?.player = null
        player?.release()
        player = null
        playerView = null
        root = null
    }

    private fun setContent(view: View) {
        setContentView(view)
    }

    private fun passwordField(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(MUTED)
        setTextColor(WHITE)
        textSize = 16f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        setSingleLine(true)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = roundedBackground(PANEL, 12)
    }

    private fun actionButton(label: String, action: () -> Unit): TextView = text(label, 12, if (label == "ADD" || label == "UNLOCK" || label == "CREATE VAULT") BG else WHITE, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = roundedBackground(if (label == "ADD" || label == "UNLOCK" || label == "CREATE VAULT") LIME else PANEL, 10)
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun note(value: String): TextView = text(value, 13, MUTED, false)

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun fieldParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun weightParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(3); marginEnd = dp(3) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun roundedBackground(color: Int, radius: Int): android.graphics.drawable.Drawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
