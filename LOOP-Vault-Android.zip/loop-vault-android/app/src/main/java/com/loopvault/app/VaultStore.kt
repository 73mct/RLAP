package com.loopvault.app

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.AEADBadTagException
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Private, encrypted-on-disk video storage. No video bytes are sent anywhere. */
class VaultStore(private val resolver: ContentResolver, private val root: File, private val playbackRoot: File) {
    private val saltFile = File(root, "vault.salt")
    private val indexFile = File(root, "vault.index")
    private val videosDir = File(root, "videos")
    private val random = SecureRandom()

    data class VideoItem(val id: String, val name: String, val extension: String)

    fun isReady(): Boolean = saltFile.isFile && indexFile.isFile

    fun isPristine(): Boolean = !saltFile.exists() && !indexFile.exists() && (!videosDir.exists() || videosDir.listFiles().isNullOrEmpty())

    fun createVault(password: CharArray): ByteArray {
        root.mkdirs()
        videosDir.mkdirs()
        val salt = ByteArray(16).also(random::nextBytes)
        saltFile.writeBytes(salt)
        val key = deriveKey(password, salt)
        saveItems(emptyList(), key)
        salt.fill(0)
        return key
    }

    @Throws(AEADBadTagException::class)
    fun unlock(password: CharArray): ByteArray {
        val salt = saltFile.readBytes()
        val key = deriveKey(password, salt)
        salt.fill(0)
        // Authentication is checked before the key is accepted by the Activity.
        try {
            readItems(key)
            return key
        } catch (e: Exception) {
            key.fill(0)
            throw e
        }
    }

    fun readItems(key: ByteArray): MutableList<VideoItem> {
        if (!indexFile.exists()) return mutableListOf()
        val plain = decryptBlob(indexFile.readBytes(), key)
        try {
            val array = JSONArray(String(plain, StandardCharsets.UTF_8))
            val result = mutableListOf<VideoItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val item = VideoItem(obj.getString("id"), obj.getString("name"), obj.optString("extension", "mp4"))
                if (File(videosDir, "${item.id}.lrv").isFile) result.add(item)
            }
            return result
        } finally {
            plain.fill(0)
        }
    }

    fun saveItems(items: List<VideoItem>, key: ByteArray) {
        root.mkdirs()
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().put("id", item.id).put("name", item.name).put("extension", item.extension))
        }
        val encrypted = encryptBlob(array.toString().toByteArray(StandardCharsets.UTF_8), key)
        val temp = File(root, "vault.index.tmp")
        FileOutputStream(temp).use { it.write(encrypted); it.fd.sync() }
        try {
            Files.move(temp.toPath(), indexFile.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(temp.toPath(), indexFile.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        encrypted.fill(0)
    }

    fun importVideo(uri: Uri, key: ByteArray): VideoItem {
        videosDir.mkdirs()
        val displayName = queryDisplayName(uri) ?: "video-${System.currentTimeMillis()}.mp4"
        val safeName = displayName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "Video.mp4" }
        val extension = safeName.substringAfterLast('.', "mp4").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "mp4" }
        val id = UUID.randomUUID().toString()
        val target = File(videosDir, "$id.lrv")
        val temp = File(videosDir, "$id.tmp")
        val nonce = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        try {
            val input = resolver.openInputStream(uri) ?: throw IllegalStateException("Android could not open this video")
            try {
                FileOutputStream(temp).use { fileOut ->
                    fileOut.write(nonce)
                    CipherOutputStream(fileOut, cipher).use { cipherOut ->
                        input.copyTo(cipherOut, 64 * 1024)
                    }
                }
            } finally {
                input.close()
            }
            if (!temp.renameTo(target)) throw IllegalStateException("Could not finish saving the encrypted video")
            return VideoItem(id, safeName, extension)
        } catch (e: Exception) {
            temp.delete()
            target.delete()
            throw e
        } finally {
            nonce.fill(0)
        }
    }

    fun decryptForPlayback(item: VideoItem, key: ByteArray): File {
        playbackRoot.mkdirs()
        val encryptedFile = File(videosDir, "${item.id}.lrv")
        if (!encryptedFile.isFile) throw IllegalStateException("This video is missing from the vault")
        val output = File(playbackRoot, "${item.id}.${item.extension}")
        output.delete()
        try {
            FileInputStream(encryptedFile).use { input ->
            val nonce = ByteArray(12)
            var read = 0
            while (read < nonce.size) {
                val count = input.read(nonce, read, nonce.size - read)
                if (count <= 0) throw IllegalStateException("Encrypted video is damaged")
                read += count
            }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            nonce.fill(0)
            CipherInputStream(input, cipher).use { clearInput ->
                FileOutputStream(output).use { clearOutput ->
                    val buffer = ByteArray(64 * 1024)
                    try {
                        while (true) {
                            if (Thread.currentThread().isInterrupted) throw InterruptedException("Playback decryption cancelled")
                            val count = clearInput.read(buffer)
                            if (count < 0) break
                            clearOutput.write(buffer, 0, count)
                        }
                    } finally {
                        buffer.fill(0)
                    }
                }
            }
            }
        } catch (e: Exception) {
            if (e is InterruptedException) Thread.interrupted() // Clear the worker thread flag before its next task.
            output.delete()
            throw e
        }
        return output
    }

    fun deleteVideo(item: VideoItem) {
        File(videosDir, "${item.id}.lrv").delete()
        File(playbackRoot, "${item.id}.${item.extension}").delete()
    }

    fun clearPlaybackCopies() {
        if (playbackRoot.exists()) playbackRoot.listFiles()?.forEach { it.delete() }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, 310_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
            password.fill('\u0000')
        }
    }

    private fun encryptBlob(plain: ByteArray, key: ByteArray): ByteArray {
        val nonce = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        val cipherText = cipher.doFinal(plain)
        return ByteArray(nonce.size + cipherText.size).also { out ->
            System.arraycopy(nonce, 0, out, 0, nonce.size)
            System.arraycopy(cipherText, 0, out, nonce.size, cipherText.size)
            nonce.fill(0)
            cipherText.fill(0)
            plain.fill(0)
        }
    }

    @Throws(AEADBadTagException::class)
    private fun decryptBlob(blob: ByteArray, key: ByteArray): ByteArray {
        if (blob.size < 28) throw IllegalStateException("Vault index is damaged")
        val nonce = blob.copyOfRange(0, 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        nonce.fill(0)
        return try { cipher.doFinal(blob, 12, blob.size - 12) } finally { blob.fill(0) }
    }
}
