package com.loopvault.app

import android.content.Context
import android.view.MotionEvent
import android.widget.FrameLayout
import kotlin.math.abs

class SwipeFrameLayout(context: Context) : FrameLayout(context) {
    var onSwipe: ((Int) -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var sent = false

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                sent = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (!sent && abs(dy) > 72f && abs(dy) > abs(dx) * 1.2f) {
                    sent = true
                    onSwipe?.invoke(if (dy < 0) 1 else -1)
                    return true
                }
            }
        }
        return super.onInterceptTouchEvent(event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return true
    }
}
