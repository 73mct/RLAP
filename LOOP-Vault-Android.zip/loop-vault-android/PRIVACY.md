# Privacy design notes

- Video imports use Android's Storage Access Framework document picker. No broad storage permission is requested.
- The selected source URI is read locally and copied into `noBackupFilesDir/loop-vault/videos`.
- Each video is encrypted with AES/GCM/NoPadding using a 256-bit key derived from the password using PBKDF2WithHmacSHA256 (310,000 iterations) and a per-vault random salt. Each file gets its own random 96-bit GCM nonce, stored before the ciphertext.
- The video list and display names are stored in an encrypted AES-GCM index file.
- The password and derived key are not written to preferences or disk. The activity clears its in-memory key byte array when locking/destroying.
- For playback, the selected file is decrypted to the app's private cache so Media3 can seek. The cache is cleared on lock and at next launch. This creates a temporary plaintext-at-rest window while a video is playing.
- `FLAG_SECURE` asks Android to block screenshots and screen recording of the app window.
- Android backup is disabled and data-extraction rules exclude app data.

This design reduces casual exposure but cannot protect a device that is rooted, compromised, unlocked and under another person's control, or subject to forensic access. Deleting a temporary file is not a guarantee of physical erasure from flash storage. Users should keep backups of original files and should not treat LOOP as a substitute for device-level security.
