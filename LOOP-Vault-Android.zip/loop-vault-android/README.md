# LOOP — Private Reels for Android

LOOP is a small native Android video vault with a vertical Reels-style player. It is designed for personal, offline use. It is not a website or a hosted video service.

## What it does

- Imports one or many videos from Android's document picker.
- Copies them into LOOP's private app storage and encrypts them with AES-256-GCM.
- Protects the vault with a password-derived key (PBKDF2-HMAC-SHA256, 310,000 iterations).
- Shows videos in a full-screen player. Swipe up/down, use Previous/Next, and videos advance automatically when they finish.
- Offers Fit and Fill viewing, video library selection, deletion, landscape orientation, and a Lock button.
- Locks after the app has stayed in the background for about one minute.
- Blocks screenshots/recording through Android's secure-window flag.
- Disables Android app backup for the vault data.

There is no user account, upload endpoint, analytics SDK, or video-sharing feature in this project.

## Important privacy and recovery details

1. **Your videos are not included in this project or its APK.** GitHub receives the source code only. Imported videos stay in the app's private data directory on the phone as encrypted `.lrv` files. They do not appear in Gallery or ordinary file browsing.
2. **Playback needs a temporary decrypted copy.** To let Android's video player seek smoothly, LOOP decrypts the selected video into its private cache while it is being watched. That temporary file is removed when you lock the vault and cleaned up on the next app launch. It is not placed in Downloads or Gallery. As with any app, a rooted or compromised phone, or someone examining the device while the vault is unlocked, may expose data.
3. **Do not forget your password.** It is not stored, and there is no reset/recovery feature. Forgetting it means the encrypted videos cannot be opened.
4. **Do not uninstall LOOP or clear its app storage** unless you have decided to delete the vault. Android removes the app's private files when app data is cleared or the app is uninstalled.
5. Keep separate copies of important original videos. Encryption protects the app's copy; it is not a backup system.
6. Large videos require free space for both the encrypted copy and a temporary playback copy (roughly the size of the video currently being watched).

## Build the APK on GitHub (no Android Studio required)

The included GitHub Actions workflow builds a signed, installable debug APK automatically whenever you push to `main`, and also supports a manual run.

1. On GitHub, create a new repository. A public or private repository works; choose **Private** if you prefer to keep the source project private.
2. Extract this ZIP on a computer or phone. Upload the **contents** of the extracted `loop-vault-android` folder into the repository's top level. Do not upload only the ZIP itself. The `.github/workflows/build-apk.yml` file must end up at that exact path in the repository.
3. Commit the files to the `main` branch. GitHub Actions should start automatically. If it does not, open the repository's **Actions** tab and enable Actions for the repository.
4. Open the **Build LOOP Android APK** workflow and select the newest successful run.
5. In the run's **Artifacts** section, download **LOOP-Private-Reels-APK**. Extract that downloaded artifact ZIP; inside it is `app-debug.apk`.
6. Open `app-debug.apk` on your Android phone and approve **Install unknown apps** for the browser or file manager when Android asks. Then open LOOP.
7. On first launch, create a password, then tap **ADD** to select your video files.

### Updating later

Push updated project files to `main`, wait for a successful workflow, and install the new `app-debug.apk` over the existing app. The workflow caches its signing key to keep later builds signed consistently. Do not uninstall the existing app to update it. If the Actions signing-key cache is ever deleted or expires, Android may reject an update signed with a new key; uninstalling in that situation deletes the app's local vault.

## Build configuration

- Android application ID: `com.loopvault.app`
- Minimum Android version: Android 8.0 (API 26)
- Compile SDK: 36
- Target SDK: 35
- Gradle: 8.13
- Android Gradle Plugin: 8.13.2
- Kotlin Gradle Plugin: 2.3.21
- AndroidX Media3: 1.11.1

## Project structure

- `app/src/main/java/com/loopvault/app/MainActivity.kt` — Android UI, password entry, video navigation and playback.
- `app/src/main/java/com/loopvault/app/VaultStore.kt` — AES-GCM file encryption and encrypted library index.
- `app/src/main/java/com/loopvault/app/SwipeFrameLayout.kt` — vertical swipe detection.
- `app/src/main/AndroidManifest.xml` — app entry point, backup restrictions and screen support.
- `.github/workflows/build-apk.yml` — GitHub Actions APK build.

## Current limitations

- This is a straightforward personal-use vault, not a professionally audited security product.
- The app stores only copies imported into LOOP; deleting a vault item does not delete the original file you selected.
- It currently supports local video files that the Android/Media3 playback stack can decode. DRM-protected files and unusual codecs may not play.
- No password change, export-from-vault, cloud sync, or recovery option is included.
